﻿namespace DogAdoptionWebsite.Models
{
    public class ContactUs
    {
    }
}
