﻿namespace DogAdoptionWebsite.Models
{
    public class Donation
    {
    }
}
